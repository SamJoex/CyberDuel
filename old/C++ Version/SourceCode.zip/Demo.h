/* ~[ Demo Mode | HEADER ]~
 * Contains the headers for Demo Mode's functions.
 */

#ifndef DEMO_H
#define DEMO_H

void DemoMode();
void DemoList();

#endif